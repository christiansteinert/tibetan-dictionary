#!/bin/bash

./make-tests.pl < test.in > test.txt
