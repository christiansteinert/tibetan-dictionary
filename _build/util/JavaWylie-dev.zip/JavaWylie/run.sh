#!/bin/sh

javac -g Test.java && java Test
