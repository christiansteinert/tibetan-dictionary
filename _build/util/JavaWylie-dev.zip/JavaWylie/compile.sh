#!/bin/sh

# this is enough to pull the rest
javac -g Test.java TestToWylie.java RunTests.java 

